<html>

<h1>Inscription</h1>

<form action="./?action=Inscription" method="POST">

    <input type="text" name="INE" placeholder="INE" /><br />
    <input type="text" name="NomEleve" placeholder="nom" /><br />
    <input type="text" name="PrenomEleve" placeholder="prenom"  /><br />
    <input type="text" name="email" placeholder="email" /><br />
    <input type="password" name="mdp" placeholder="mdp" /><br />


    <button type="submit">Inscription</button>
    <!--<input type="submit" href= "./Vue/vueConnexion.php" value="S'inscrire" /> -->


</form>

</html>