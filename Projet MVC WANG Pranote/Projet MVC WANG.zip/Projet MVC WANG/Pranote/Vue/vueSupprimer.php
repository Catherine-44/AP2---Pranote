<html>

<div class="message">Vos informations ont bien été supprimée !<br />

</html>