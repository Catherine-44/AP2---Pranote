<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd%22%3E">
<html>
    <head>
    <meta charset="UTF-8">  
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
        <title><?php echo $titre ?></title>
        <style type="text/css">
            @import url("css/base.css");
            @import url("css/form.css");
            @import url("css/corps.css");
        </style>
        <link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
    </head>
    <body>
    <nav>

        <ul id="menuGeneral">
            <li><a href="./?action=accueil">Accueil</a></li> 
            <li><a href="./?action=Controle">Controle</a></li>
            <li><a href="./?action=Cours">Cours</a></li>
            <li><a href="./?action=Profil.php">Mon profil</a></li>
            <li><a href="./?action=deconnexion">Se deconnecter</a></li>
        </ul>
    </nav>
    <div id="bouton">
        <div></div> 
        <div></div>
        <div></div>
    </div>
    <ul id="menuContextuel">
        <li><img src="Photos/logo.jpg" alt="logo" width="80" /></li>
    </ul>

    <div id="corps">